package com.rocketnia.hacks.myregex;

public class RegexMultipleMacroDefinitionException extends Exception
{
    static final long serialVersionUID = 1;

    public RegexMultipleMacroDefinitionException()
    {
        super();
    }
}
